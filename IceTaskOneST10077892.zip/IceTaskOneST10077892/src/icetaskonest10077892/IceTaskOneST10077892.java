package icetaskonest10077892;
import java.util.Scanner;
public class IceTaskOneST10077892 {

    
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of adult meals ordered: ");
        int adultMeals = scanner.nextInt();

        System.out.print("Enter the number of children's meals ordered: ");
        int childrenMeals = scanner.nextInt();

        double adultTotal = adultMeals * 7.0;

        double childrenTotal = childrenMeals * 4.0;
        
        double total = adultTotal + childrenTotal;

        System.out.println("Total money collected for adult meals: $" + adultTotal);
        
        System.out.println("Total money collected for children's meals: $" + childrenTotal);

        System.out.println("Total money collected for all meals: $" + total);

        scanner.close();

    }
    
}
